package com.example.fibonaccim501;

import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigInteger;

/** Actividad Java con controles XML y navegacion por Fibonacci. */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "FibonacciM5";
    // Limite practico para evitar bloquear la interfaz con numeros enormes.
    private static final int MAX_N = 10000;

    private final FibonacciMemo fibonacci = new FibonacciMemo();
    private TextView textoValor;
    private TextView textoIndice;
    private EditText entradaIndice;
    private Button botonRetroceder;
    private Button botonAvanzar;

    // n=0 representa la pantalla inicial: el primer clic mostrara F(1)=1.
    private int indiceActual = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textoValor = findViewById(R.id.textoValor);
        textoIndice = findViewById(R.id.textoIndice);
        entradaIndice = findViewById(R.id.entradaIndice);
        botonRetroceder = findViewById(R.id.botonRetroceder);
        botonAvanzar = findViewById(R.id.botonAvanzar);

        if (savedInstanceState != null) {
            indiceActual = Math.max(0, Math.min(MAX_N,
                    savedInstanceState.getInt("indiceActual", 0)));
        }

        botonAvanzar.setOnClickListener(v -> mostrarIndice(indiceActual + 1));
        botonRetroceder.setOnClickListener(v -> {
            if (indiceActual > 0) {
                mostrarIndice(indiceActual - 1);
            }
        });

        // Extra opcional: permite consultar un n especifico sin agregar un tercer boton.
        // Se escribe n y se presiona la tecla "Listo" del teclado.
        entradaIndice.setOnEditorActionListener((v, accion, evento) -> {
            if (accion == EditorInfo.IME_ACTION_DONE) {
                consultarIndiceEscrito();
                return true;
            }
            return false;
        });

        actualizarVista();
    }

    private void consultarIndiceEscrito() {
        String contenido = entradaIndice.getText().toString().trim();
        try {
            int n = Integer.parseInt(contenido);
            if (n < 1 || n > MAX_N) {
                mostrarAviso(getString(R.string.error_rango, MAX_N));
                return;
            }
            mostrarIndice(n);
        } catch (NumberFormatException ex) {
            mostrarAviso(getString(R.string.error_entero));
        }
    }

    private void mostrarIndice(int nuevoIndice) {
        if (nuevoIndice < 0 || nuevoIndice > MAX_N) {
            mostrarAviso(getString(R.string.error_rango, MAX_N));
            return;
        }
        indiceActual = nuevoIndice;
        actualizarVista();
    }

    private void actualizarVista() {
        botonRetroceder.setEnabled(indiceActual > 0);
        botonAvanzar.setEnabled(indiceActual < MAX_N);

        if (indiceActual == 0) {
            textoIndice.setText(R.string.indice_inicial);
            textoValor.setText(R.string.mensaje_inicial);
            return;
        }

        BigInteger valor = fibonacci.obtener(indiceActual);
        textoIndice.setText(getString(R.string.indice_actual, indiceActual));
        textoValor.setText(valor.toString());
        Log.i(TAG, "n=" + indiceActual + " | Fibonacci=" + valor);
    }

    private void mostrarAviso(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show();
        Log.w(TAG, mensaje);
    }

    @Override
    protected void onSaveInstanceState(Bundle estado) {
        estado.putInt("indiceActual", indiceActual);
        super.onSaveInstanceState(estado);
    }
}
