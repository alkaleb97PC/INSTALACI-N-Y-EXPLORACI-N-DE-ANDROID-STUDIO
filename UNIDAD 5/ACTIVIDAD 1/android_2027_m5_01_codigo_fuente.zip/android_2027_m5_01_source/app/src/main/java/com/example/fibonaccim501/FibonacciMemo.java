package com.example.fibonaccim501;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/** Calcula F(n) con un ciclo for y memoizacion. */
public final class FibonacciMemo {
    private final List<BigInteger> memoria = new ArrayList<>();

    public FibonacciMemo() {
        memoria.add(BigInteger.ZERO); // F(0) = 0
        memoria.add(BigInteger.ONE);  // F(1) = 1
    }

    /** Devuelve F(n). F(1)=1, F(2)=1, F(3)=2... */
    public synchronized BigInteger obtener(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("El indice n debe ser no negativo");
        }
        // Solo calcula los valores que aun no se encuentran en memoria.
        for (int i = memoria.size(); i <= n; i++) {
            BigInteger siguiente = memoria.get(i - 1).add(memoria.get(i - 2));
            memoria.add(siguiente);
        }
        return memoria.get(n);
    }

    public synchronized int cantidadMemorizada() {
        return memoria.size();
    }
}
