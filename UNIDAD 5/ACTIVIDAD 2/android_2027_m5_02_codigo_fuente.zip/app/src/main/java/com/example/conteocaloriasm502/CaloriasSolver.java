package com.example.conteocaloriasm502;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;

/** Resuelve el conteo de calorias sin depender de Android. */
public final class CaloriasSolver {
    private CaloriasSolver() { }

    public static Resultado analizar(Reader entrada) throws IOException {
        BufferedReader lector = new BufferedReader(entrada);
        long sumaActual = 0;
        long sumaMaxima = Long.MIN_VALUE;
        int numeroElfo = 0;
        int elfoGanador = 0;
        int alimentosActuales = 0;
        int alimentosGanador = 0;
        boolean grupoConDatos = false;
        String linea;

        while ((linea = lector.readLine()) != null) {
            String dato = linea.trim();
            if (dato.isEmpty()) {
                if (grupoConDatos) {
                    numeroElfo++;
                    if (sumaActual > sumaMaxima) {
                        sumaMaxima = sumaActual;
                        elfoGanador = numeroElfo;
                        alimentosGanador = alimentosActuales;
                    }
                    sumaActual = 0;
                    alimentosActuales = 0;
                    grupoConDatos = false;
                }
                continue;
            }

            try {
                long calorias = Long.parseLong(dato);
                if (calorias < 0) {
                    throw new IOException("No se permiten calorias negativas: " + dato);
                }
                sumaActual = Math.addExact(sumaActual, calorias);
            } catch (NumberFormatException | ArithmeticException ex) {
                throw new IOException("Dato invalido: " + dato, ex);
            }
            alimentosActuales++;
            grupoConDatos = true;
        }
        // La ultima linea del archivo puede no estar seguida de una linea vacia.
        if (grupoConDatos) {
            numeroElfo++;
            if (sumaActual > sumaMaxima) {
                sumaMaxima = sumaActual;
                elfoGanador = numeroElfo;
                alimentosGanador = alimentosActuales;
            }
        }
        if (numeroElfo == 0) {
            throw new IOException("La entrada no contiene elfos.");
        }
        return new Resultado(numeroElfo, elfoGanador, sumaMaxima, alimentosGanador);
    }

    public static final class Resultado {
        public final int cantidadElfos;
        public final int numeroElfoGanador;
        public final long maximoCalorias;
        public final int alimentosGanador;

        public Resultado(int cantidadElfos, int numeroElfoGanador,
                         long maximoCalorias, int alimentosGanador) {
            this.cantidadElfos = cantidadElfos;
            this.numeroElfoGanador = numeroElfoGanador;
            this.maximoCalorias = maximoCalorias;
            this.alimentosGanador = alimentosGanador;
        }
    }
}
