package com.example.conteocaloriasm502;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Activity sin interfaz grafica: el resultado se imprime en Logcat. */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "CaloriasM502";
    private static final String URL_DATOS =
            "https://raw.githubusercontent.com/" +
            "CristianCardosoA/FCA-IOS-2023-1/main/inputs/input-M5-02";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // La tarea de red se ejecuta fuera del hilo principal.
        new Thread(this::resolverProblema, "CaloriasWorker").start();
    }

    private void resolverProblema() {
        Log.i(TAG, "=== INICIO DE CONTEO DE CALORIAS ===");
        try {
            CaloriasSolver.Resultado resultado;
            // Si existe el archivo en assets, se usa sin conexion.
            try (InputStream entrada = abrirDatos();
                 InputStreamReader lector = new InputStreamReader(
                         entrada, StandardCharsets.UTF_8)) {
                resultado = CaloriasSolver.analizar(lector);
            }
            Log.i(TAG, "Elfos analizados: " + resultado.cantidadElfos);
            Log.i(TAG, "Elfo con mas calorias: " + resultado.numeroElfoGanador);
            Log.i(TAG, "Cantidad maxima de calorias: " + resultado.maximoCalorias);
            Log.i(TAG, "Alimentos del elfo ganador: " + resultado.alimentosGanador);
            Log.i(TAG, "=== FIN DE RESULTADOS ===");
        } catch (Exception e) {
            Log.e(TAG, "No se pudo procesar el archivo de entrada: "
                    + e.getMessage(), e);
        }
    }

    private InputStream abrirDatos() throws IOException {
        try {
            InputStream local = getAssets().open("input-M5-02.txt");
            Log.i(TAG, "Fuente: archivo local en assets/input-M5-02.txt");
            return local;
        } catch (FileNotFoundException ex) {
            Log.i(TAG, "Fuente: descarga del archivo original en GitHub");
        }
        // URLConnection desconecta al cerrar la respuesta en la Activity.
        HttpURLConnection conexion =
                (HttpURLConnection) new URL(URL_DATOS).openConnection();
        conexion.setConnectTimeout(12000);
        conexion.setReadTimeout(12000);
        conexion.setRequestMethod("GET");
        int codigo = conexion.getResponseCode();
        if (codigo != HttpURLConnection.HTTP_OK) {
            conexion.disconnect();
            throw new IOException("HTTP " + codigo + " al descargar la entrada");
        }
        return conexion.getInputStream();
    }
}
