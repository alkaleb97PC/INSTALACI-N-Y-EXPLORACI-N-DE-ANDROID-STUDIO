import java.io.FileReader;
import com.example.conteocaloriasm502.CaloriasSolver;

public class PruebaConsola {
    public static void main(String[] args) throws Exception {
        CaloriasSolver.Resultado r =
                CaloriasSolver.analizar(new FileReader(args[0]));
        System.out.println("Elfos: " + r.cantidadElfos);
        System.out.println("Elfo ganador: " + r.numeroElfoGanador);
        System.out.println("Calorias maximas: " + r.maximoCalorias);
    }
}
