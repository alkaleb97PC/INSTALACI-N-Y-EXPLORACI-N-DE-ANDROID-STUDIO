package mx.fca.aviones;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public final class MainActivity extends AppCompatActivity {
    private static final String TAG = "AvionesM6";
    private Plano plano;
    private AvionAdapter adapter;
    private Button btnNext;
    private Button btnPrev;
    private TextView txtPaso, txtAviones, txtColisiones, txtTotal;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnNext = findViewById(R.id.btnNext);
        btnPrev = findViewById(R.id.btnPrev);
        txtPaso = findViewById(R.id.txtPaso);
        txtAviones = findViewById(R.id.txtAviones);
        txtColisiones = findViewById(R.id.txtColisiones);
        txtTotal = findViewById(R.id.txtTotal);
        RecyclerView grid = findViewById(R.id.listaAviones);
        plano = Planificador.crearRutaInicial();
        adapter = new AvionAdapter(plano);
        grid.setLayoutManager(new GridLayoutManager(this, Planificador.COLUMNAS));
        grid.setAdapter(adapter);
        grid.setNestedScrollingEnabled(false);

        btnNext.setOnClickListener(v -> {
            if (plano.getNumeroAviones() > 0) {
                plano = plano.next();
                refrescar();
            }
        });
        btnPrev.setOnClickListener(v -> {
            if (plano.noPaso > 0) {
                plano = plano.prev();
                refrescar();
            }
        });
        refrescar();
    }

    private void refrescar() {
        txtPaso.setText("Paso: " + plano.noPaso);
        txtAviones.setText("Aviones: " + plano.getNumeroAviones());
        txtColisiones.setText("Colisiones en paso: " + plano.getNumeroColisiones());
        txtTotal.setText("Total acumulado: " + plano.colisionesAcumuladas);
        btnPrev.setEnabled(plano.noPaso > 0);
        btnNext.setEnabled(plano.getNumeroAviones() > 0);
        adapter.actualizar(plano);
        Log.i(TAG, "Paso=" + plano.noPaso + " Aviones=" + plano.getNumeroAviones()
                + " ColisionesPaso=" + plano.getNumeroColisiones()
                + " Acumuladas=" + plano.colisionesAcumuladas);
        for (Colision c : plano.colisiones) {
            Log.i(TAG, "Colision en (" + c.x + "," + c.y +
                    ") con " + c.avionesInvolucrados + " aviones");
        }
    }
}
