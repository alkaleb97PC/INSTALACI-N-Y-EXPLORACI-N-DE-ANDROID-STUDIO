package mx.fca.aviones;

import org.junit.Test;
import static org.junit.Assert.*;

public class AnalizadorTest {
    @Test public void choqueDelCasoOriginal() {
        Plano cero = Planificador.crearRutaInicial();
        assertEquals(0, cero.getNumeroColisiones());
        Plano uno = cero.next();
        assertEquals(1, uno.getNumeroColisiones());
        assertEquals(1, uno.colisionesAcumuladas);
        assertEquals(1, uno.colisiones.get(0).x);
        assertEquals(0, uno.colisiones.get(0).y);
        assertSame(cero, uno.prev());
        assertSame(uno, cero.next());
        assertEquals(0, cero.aviones.get(0).x);
    }
    @Test public void dosColisionesEnUnPaso() {
        Plano cero = Planificador.crearRutaInicial(Aerolineas.DOS_COLISIONES());
        assertEquals(2, cero.next().getNumeroColisiones());
    }
}
