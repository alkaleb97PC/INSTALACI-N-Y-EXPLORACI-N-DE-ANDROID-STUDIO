package mx.fca.aviones;

/** Representa un avion del tablero; su posicion nunca se modifica en sitio. */
public final class Avion {
    public final Direccion direccion;
    public final int x;
    public final int y;

    public Avion(Direccion direccion, int x, int y) {
        if (direccion == null) throw new IllegalArgumentException("Direccion requerida");
        this.direccion = direccion;
        this.x = x;
        this.y = y;
    }

    public Avion avanzar() {
        switch (direccion) {
            case NORTH: return new Avion(direccion, x, y - 1);
            case SOUTH: return new Avion(direccion, x, y + 1);
            case EAST: return new Avion(direccion, x + 1, y);
            case WEST: return new Avion(direccion, x - 1, y);
            default: throw new IllegalStateException("Direccion desconocida");
        }
    }

    public int getImage() {
        switch (direccion) {
            case NORTH: return R.mipmap.north;
            case SOUTH: return R.mipmap.south;
            case EAST: return R.mipmap.east;
            case WEST: return R.mipmap.west;
            default: return R.mipmap.north;
        }
    }
}
