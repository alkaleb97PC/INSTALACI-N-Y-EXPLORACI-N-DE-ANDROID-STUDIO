package mx.fca.aviones;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

/** Instantanea inmutable de un paso de la simulacion. */
public final class Plano {
    public final List<Avion> aviones;
    public final List<Colision> colisiones;
    public final int col;
    public final int row;
    public final int noPaso;
    public final int colisionesAcumuladas;

    Plano(int noPaso, ArrayList<Avion> aviones, ArrayList<Colision> colisiones,
          int colisionesAcumuladas, int columnas, int renglones) {
        this.noPaso = noPaso;
        this.aviones = Collections.unmodifiableList(new ArrayList<>(aviones));
        this.colisiones = Collections.unmodifiableList(new ArrayList<>(colisiones));
        this.colisionesAcumuladas = colisionesAcumuladas;
        this.col = columnas;
        this.row = renglones;
    }

    public Plano next() { return Analizador.next(noPaso + 1, this); }
    public Plano prev() { return Analizador.prev(Math.max(0, noPaso - 1)); }
    public int getNumeroColisiones() { return colisiones.size(); }
    public int getNumeroAviones() { return aviones.size(); }
}
