package mx.fca.aviones;

/** Una colision corresponde a una celda ocupada por 2 o mas aviones. */
public final class Colision {
    public final int x;
    public final int y;
    public final int avionesInvolucrados;

    public Colision(int x, int y, int avionesInvolucrados) {
        this.x = x;
        this.y = y;
        this.avionesInvolucrados = avionesInvolucrados;
    }

    public int getImage() { return R.mipmap.collision; }
}
