package mx.fca.aviones;

import java.util.ArrayList;

/** Casos de ejemplo editables para incorporar casos del profesor. */
public final class Aerolineas {
    private Aerolineas() { }

    // Caso que viene en el proyecto base: colision en (1,0) tras un paso.
    public static ArrayList<Avion> AEROMEXICO() {
        ArrayList<Avion> aviones = new ArrayList<>();
        aviones.add(new Avion(Direccion.EAST, 0, 0));
        aviones.add(new Avion(Direccion.WEST, 2, 0));
        return aviones;
    }

    // Dos colisiones simultaneas, para ampliar las pruebas.
    public static ArrayList<Avion> DOS_COLISIONES() {
        ArrayList<Avion> aviones = new ArrayList<>();
        aviones.add(new Avion(Direccion.EAST, 1, 2));
        aviones.add(new Avion(Direccion.WEST, 3, 2));
        aviones.add(new Avion(Direccion.SOUTH, 5, 1));
        aviones.add(new Avion(Direccion.NORTH, 5, 3));
        return aviones;
    }
}
