package mx.fca.aviones;

import java.util.ArrayList;

public final class Planificador {
    public static final int COLUMNAS = 7;
    public static final int FILAS = 7;
    private Planificador() { }

    public static Plano crearRutaInicial() {
        // Sustituir por Aerolineas.DOS_COLISIONES() para otra prueba.
        return crearRutaInicial(Aerolineas.AEROMEXICO());
    }

    public static Plano crearRutaInicial(ArrayList<Avion> aviones) {
        for (Avion a : aviones) {
            if (a.x < 0 || a.x >= COLUMNAS || a.y < 0 || a.y >= FILAS) {
                throw new IllegalArgumentException("Avion fuera del tablero");
            }
        }
        return Analizador.inicializa(new Plano(0, aviones,
                new ArrayList<>(), 0, COLUMNAS, FILAS));
    }
}
