package mx.fca.aviones;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

/** Aplica movimientos discretos y memoriza cada estado para retroceder. */
public final class Analizador {
    private static final HashMap<Integer, Plano> memoria = new HashMap<>();
    private Analizador() { }

    public static Plano inicializa(Plano plano) {
        memoria.clear();
        ArrayList<Colision> colisionesIniciales = detectarColisiones(plano.aviones);
        Plano inicial = new Plano(0, new ArrayList<>(plano.aviones), colisionesIniciales,
                colisionesIniciales.size(), plano.col, plano.row);
        memoria.put(0, inicial);
        return inicial;
    }

    public static Plano next(int noPaso, Plano anterior) {
        if (noPaso != anterior.noPaso + 1) {
            throw new IllegalArgumentException("Paso no consecutivo");
        }
        if (memoria.containsKey(noPaso)) return memoria.get(noPaso);

        ArrayList<Avion> nuevos = new ArrayList<>();
        for (Avion avion : anterior.aviones) {
            Avion siguiente = avion.avanzar();
            // Sale del tablero: deja de ser un avion activo.
            if (siguiente.x < 0 || siguiente.x >= anterior.col ||
                    siguiente.y < 0 || siguiente.y >= anterior.row) continue;
            nuevos.add(siguiente);
        }
        ArrayList<Colision> colisiones = detectarColisiones(nuevos);
        Plano nuevo = new Plano(noPaso, nuevos, colisiones,
                anterior.colisionesAcumuladas + colisiones.size(), anterior.col, anterior.row);
        memoria.put(noPaso, nuevo);
        return nuevo;
    }

    private static ArrayList<Colision> detectarColisiones(List<Avion> aviones) {
        Map<String, Integer> ocupacion = new LinkedHashMap<>();
        for (Avion avion : aviones) {
            String celda = avion.x + "," + avion.y;
            ocupacion.put(celda, ocupacion.containsKey(celda)
                    ? ocupacion.get(celda) + 1 : 1);
        }
        ArrayList<Colision> resultado = new ArrayList<>();
        for (Map.Entry<String, Integer> par : ocupacion.entrySet()) {
            if (par.getValue() > 1) {
                String[] xy = par.getKey().split(",");
                resultado.add(new Colision(Integer.parseInt(xy[0]),
                        Integer.parseInt(xy[1]), par.getValue()));
            }
        }
        return resultado;
    }

    public static Plano prev(int noPaso) {
        Plano plano = memoria.get(Math.max(0, noPaso));
        if (plano == null) throw new IllegalStateException("Paso no almacenado");
        return plano;
    }
}
