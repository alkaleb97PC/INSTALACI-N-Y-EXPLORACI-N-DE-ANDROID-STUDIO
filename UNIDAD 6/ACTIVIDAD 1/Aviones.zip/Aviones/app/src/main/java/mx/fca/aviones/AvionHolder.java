package mx.fca.aviones;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public final class AvionHolder extends RecyclerView.ViewHolder {
    final ImageView imgAvion;
    final TextView tvCantidad;
    public AvionHolder(@NonNull View itemView) {
        super(itemView);
        imgAvion = itemView.findViewById(R.id.imgAvion);
        tvCantidad = itemView.findViewById(R.id.tvCantidad);
    }
}
