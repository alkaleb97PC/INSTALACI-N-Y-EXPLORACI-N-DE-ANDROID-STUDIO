package mx.fca.aviones;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/** Un elemento del RecyclerView representa exactamente una celda del grid. */
public final class AvionAdapter extends RecyclerView.Adapter<AvionHolder> {
    private Plano plano;
    public AvionAdapter(Plano plano) { this.plano = plano; }

    public void actualizar(Plano nuevo) {
        plano = nuevo;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public AvionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.avion_view, parent, false);
        return new AvionHolder(view);
    }

    @Override public void onBindViewHolder(@NonNull AvionHolder holder, int position) {
        int x = position % plano.col;
        int y = position / plano.col;
        Avion primero = null;
        int cantidad = 0;
        for (Avion avion : plano.aviones) {
            if (avion.x == x && avion.y == y) {
                cantidad++;
                if (primero == null) primero = avion;
            }
        }
        holder.imgAvion.setVisibility(View.INVISIBLE);
        holder.tvCantidad.setVisibility(View.GONE);
        holder.imgAvion.setImageDrawable(null);
        holder.itemView.setContentDescription("Celda " + x + "," + y + ": vacia");
        if (cantidad > 1) {
            holder.imgAvion.setImageResource(R.mipmap.collision);
            holder.imgAvion.setVisibility(View.VISIBLE);
            holder.tvCantidad.setText(String.valueOf(cantidad));
            holder.tvCantidad.setVisibility(View.VISIBLE);
            holder.itemView.setContentDescription("Colision en " + x + "," + y +
                    " con " + cantidad + " aviones");
        } else if (primero != null) {
            holder.imgAvion.setImageResource(primero.getImage());
            holder.imgAvion.setVisibility(View.VISIBLE);
            holder.itemView.setContentDescription("Avion hacia " + primero.direccion +
                    " en " + x + "," + y);
        }
    }
    @Override public int getItemCount() { return plano.col * plano.row; }
}
