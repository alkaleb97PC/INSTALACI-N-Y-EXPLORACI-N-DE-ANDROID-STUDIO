package com.example.restpublicapis;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Practica: consulta REST HTTP GET y visualizacion de la respuesta JSON. */
public class MainActivity extends Activity {
    private static final String TAG = "RESTPublicAPIs";
    private static final String URL_ORIGINAL = "https://api.publicapis.org/entries";
    private static final String URL_ALTERNATIVA = "https://freeapi.today/api.json";
    private static final int MAX_LEER = 1024 * 1024;
    private static final int MAX_MOSTRAR = 9000;

    private TextView estado, resultado;
    private ProgressBar progreso;
    private Button botonOriginal, botonAlternativo;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        estado = findViewById(R.id.textEstado);
        resultado = findViewById(R.id.textResultado);
        progreso = findViewById(R.id.progreso);
        botonOriginal = findViewById(R.id.botonOriginal);
        botonAlternativo = findViewById(R.id.botonAlternativo);
        botonOriginal.setOnClickListener(v -> consultar(URL_ORIGINAL, "GET /entries (consigna)"));
        botonAlternativo.setOnClickListener(v -> consultar(URL_ALTERNATIVA, "GET alternativo (demostracion)"));
    }

    private void consultar(String url, String nombre) {
        progreso.setVisibility(View.VISIBLE);
        botonOriginal.setEnabled(false);
        botonAlternativo.setEnabled(false);
        estado.setText("Conectando: " + nombre);
        resultado.setText("Solicitando datos a " + url + " ...");
        // Operaciones de red fuera del hilo de la interfaz.
        new Thread(() -> {
            long inicio = System.currentTimeMillis();
            String salida;
            boolean exito = false;
            try {
                RespuestaHttp respuesta = ejecutarGet(url);
                String cuerpo = formatearJson(respuesta.cuerpo);
                if (cuerpo.length() > MAX_MOSTRAR) {
                    cuerpo = cuerpo.substring(0, MAX_MOSTRAR)
                            + "\n\n[Vista recortada a 9000 caracteres; respuesta recibida completa.]";
                }
                exito = respuesta.codigo >= 200 && respuesta.codigo < 300;
                salida = "Fuente: " + url + "\nHTTP: " + respuesta.codigo
                        + "\nTiempo: " + (System.currentTimeMillis() - inicio) + " ms"
                        + "\n\n" + cuerpo;
            } catch (Exception error) {
                salida = "No se pudo completar la solicitud HTTP GET.\n"
                        + "URL: " + url + "\n"
                        + "Motivo: " + error.getClass().getSimpleName() + ": " + error.getMessage()
                        + "\n\nSi falla api.publicapis.org, el servicio historico puede estar fuera de linea."
                        + " La opcion alternativa consulta un catalogo distinto, no el endpoint del profesor.";
                Log.e(TAG, nombre + " fallido: " + error.getMessage(), error);
            }
            final String textoFinal = salida;
            final boolean okFinal = exito;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                progreso.setVisibility(View.GONE);
                botonOriginal.setEnabled(true);
                botonAlternativo.setEnabled(true);
                estado.setText(nombre + (okFinal ? " · respuesta recibida" : " · revisar respuesta"));
                resultado.setText(textoFinal);
                Log.i(TAG, nombre + ": " + (okFinal ? "correcto" : "sin HTTP 2xx"));
            });
        }, "REST-GET-Worker").start();
    }

    private static RespuestaHttp ejecutarGet(String direccion) throws IOException {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(direccion).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(10000);
            c.setReadTimeout(12000);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "RESTPublicAPIs-Android-Practica/1.0");
            int codigo = c.getResponseCode();
            InputStream entrada = codigo >= 400 ? c.getErrorStream() : c.getInputStream();
            String cuerpo = entrada == null ? "Sin cuerpo de respuesta" : leerTexto(entrada);
            return new RespuestaHttp(codigo, cuerpo);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String leerTexto(InputStream entrada) throws IOException {
        try (BufferedReader lector = new BufferedReader(
                new InputStreamReader(entrada, StandardCharsets.UTF_8))) {
            StringBuilder texto = new StringBuilder();
            char[] bloque = new char[4096];
            int n;
            while ((n = lector.read(bloque)) != -1) {
                texto.append(bloque, 0, n);
                if (texto.length() >= MAX_LEER) {
                    texto.append("\n[La respuesta supera 1 MiB y fue truncada al leer.]");
                    break;
                }
            }
            return texto.toString();
        }
    }

    private static String formatearJson(String texto) {
        try { return new JSONObject(texto).toString(2); }
        catch (JSONException ignorado) {
            try { return new JSONArray(texto).toString(2); }
            catch (JSONException ignorado2) { return texto; }
        }
    }

    private static final class RespuestaHttp {
        final int codigo;
        final String cuerpo;
        RespuestaHttp(int codigo, String cuerpo) {
            this.codigo = codigo;
            this.cuerpo = cuerpo;
        }
    }
}
