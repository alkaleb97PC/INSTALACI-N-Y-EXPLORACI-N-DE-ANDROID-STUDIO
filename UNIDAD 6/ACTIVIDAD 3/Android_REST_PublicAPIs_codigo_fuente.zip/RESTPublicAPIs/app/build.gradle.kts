plugins { id("com.android.application") }
android {
    namespace = "com.example.restpublicapis"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.restpublicapis"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}
