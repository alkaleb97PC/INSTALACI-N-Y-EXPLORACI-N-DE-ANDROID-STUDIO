package com.example.calculadoram301;

/** Categorias de error previstas en los archivos base de la actividad. */
public enum CalculadoraError {
    DIV_ZERO, MAX_NUMBER, IMAGINARIO
}
