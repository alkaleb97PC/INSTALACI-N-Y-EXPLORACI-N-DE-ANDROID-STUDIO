package com.example.calculadoram301;

/** Contrato de formateo de resultados, sin interfaz grafica. */
public interface IDisplay {
    String muestraResultado(float res);
    String muestraError(CalculadoraError error);
}
