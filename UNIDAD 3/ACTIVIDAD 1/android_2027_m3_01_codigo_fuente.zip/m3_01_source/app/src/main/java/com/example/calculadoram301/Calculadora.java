package com.example.calculadoram301;

/** Coordina las interfaces de control, procesamiento y salida. */
public class Calculadora implements ICalculadora {
    private IControl control;
    private IDisplay display;
    private IProcesamiento procesamiento;

    @Override public void setControl(IControl control) {
        if (control == null) throw new IllegalArgumentException("Control nulo");
        this.control = control;
        conectar();
    }

    @Override public void setDisplay(IDisplay display) {
        if (display == null) throw new IllegalArgumentException("Display nulo");
        this.display = display;
    }

    @Override public void setProcesamiento(IProcesamiento procesa) {
        if (procesa == null) throw new IllegalArgumentException("Procesamiento nulo");
        this.procesamiento = procesa;
        conectar();
    }

    private void conectar() {
        if (control instanceof Control && procesamiento != null) {
            ((Control) control).setProcesamiento(procesamiento);
        }
    }

    public String ejecutar(int x, int y, Operacion operacion) {
        if (control == null || display == null || procesamiento == null) {
            throw new IllegalStateException("Falta configurar alguna interfaz");
        }
        if (operacion == null) throw new IllegalArgumentException("Operacion nula");
        control.introduceValorX(x);
        control.introduceValorY(y);
        control.introduceOperacion(operacion);
        if (operacion == Operacion.DIV && y == 0) {
            return display.muestraError(CalculadoraError.DIV_ZERO);
        }
        return validarResultado(control.igual());
    }

    /** Centraliza la validacion de resultados invalidos, incluido NaN. */
    public String validarResultado(float resultado) {
        if (display == null) throw new IllegalStateException("Display no configurado");
        if (Float.isNaN(resultado)) {
            return display.muestraError(CalculadoraError.IMAGINARIO);
        }
        if (Float.isInfinite(resultado)) {
            return display.muestraError(CalculadoraError.MAX_NUMBER);
        }
        return display.muestraResultado(resultado);
    }
}
