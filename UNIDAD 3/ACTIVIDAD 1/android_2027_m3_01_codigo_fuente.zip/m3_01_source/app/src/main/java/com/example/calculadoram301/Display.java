package com.example.calculadoram301;

/** Traduce resultados y errores a mensajes de texto. */
public class Display implements IDisplay {
    @Override public String muestraResultado(float res) {
        if (Float.isNaN(res)) return muestraError(CalculadoraError.IMAGINARIO);
        if (Float.isInfinite(res)) return muestraError(CalculadoraError.MAX_NUMBER);
        return Float.toString(res);
    }

    @Override public String muestraError(CalculadoraError error) {
        switch (error) {
            case DIV_ZERO: return "ERROR: division entre cero no permitida";
            case MAX_NUMBER: return "ERROR: resultado infinito o fuera de rango";
            case IMAGINARIO: return "ERROR: resultado NaN (no es un numero)";
            default: return "ERROR: desconocido";
        }
    }
}
