package com.example.calculadoram301;

/** Contrato principal tomado de las clases base proporcionadas. */
public interface ICalculadora {
    void setControl(IControl control);
    void setDisplay(IDisplay display);
    void setProcesamiento(IProcesamiento procesa);
}
