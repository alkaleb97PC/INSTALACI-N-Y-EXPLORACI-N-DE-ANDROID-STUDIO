package com.example.calculadoram301;

/** Entrada de operandos y operacion, segun la interfaz base. */
public interface IControl {
    void introduceValorX(int x);
    void introduceValorY(int y);
    void introduceOperacion(Operacion op);
    float igual();
}
