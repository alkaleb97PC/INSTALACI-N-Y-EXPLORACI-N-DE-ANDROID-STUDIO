package com.example.calculadoram301;

/** Recibe los dos numeros y ejecuta la operacion elegida. */
public class Control implements IControl {
    private int x;
    private int y;
    private Operacion operacion;
    private IProcesamiento procesamiento;

    public void setProcesamiento(IProcesamiento procesamiento) {
        if (procesamiento == null) throw new IllegalArgumentException("Procesamiento nulo");
        this.procesamiento = procesamiento;
    }

    @Override public void introduceValorX(int x) { this.x = x; }
    @Override public void introduceValorY(int y) { this.y = y; }
    @Override public void introduceOperacion(Operacion op) { this.operacion = op; }

    @Override public float igual() {
        if (procesamiento == null || operacion == null) {
            throw new IllegalStateException("Configuracion de calculadora incompleta");
        }
        switch (operacion) {
            case SUM: return procesamiento.suma(x, y);
            case RES: return procesamiento.resta(x, y);
            case MUL: return procesamiento.multi(x, y);
            case DIV: return procesamiento.div(x, y);
            default: throw new IllegalStateException("Operacion no soportada");
        }
    }
}
