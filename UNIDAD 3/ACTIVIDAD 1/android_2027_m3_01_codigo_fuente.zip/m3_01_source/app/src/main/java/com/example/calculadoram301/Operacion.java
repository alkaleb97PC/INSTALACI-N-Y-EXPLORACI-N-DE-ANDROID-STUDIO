package com.example.calculadoram301;

/** Cuatro operaciones aritmeticas basicas. */
public enum Operacion {
    SUM, RES, MUL, DIV
}
