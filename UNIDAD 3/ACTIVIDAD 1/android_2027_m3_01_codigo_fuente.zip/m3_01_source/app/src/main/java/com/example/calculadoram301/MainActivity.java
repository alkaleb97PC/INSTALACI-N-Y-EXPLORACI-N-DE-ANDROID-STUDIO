package com.example.calculadoram301;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

/** Activity sin elementos visuales: publica todas las pruebas en Logcat. */
public class MainActivity extends AppCompatActivity {
    private static final String TAG = "CalculadoraM3";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // No se llama a setContentView(): esta actividad no tiene interfaz grafica.
        Calculadora calculadora = new Calculadora();
        calculadora.setControl(new Control());
        calculadora.setDisplay(new Display());
        calculadora.setProcesamiento(new Procesamiento());

        Log.i(TAG, "=== INICIO DE PRUEBAS CALCULADORA ===");
        registrar(calculadora, 12, 8, Operacion.SUM, "+");
        registrar(calculadora, 12, 8, Operacion.RES, "-");
        registrar(calculadora, 12, 8, Operacion.MUL, "*");
        registrar(calculadora, 12, 8, Operacion.DIV, "/");
        registrar(calculadora, 12, 0, Operacion.DIV, "/");
        registrar(calculadora, 0, 0, Operacion.DIV, "/");
        Log.i(TAG, "Prueba explicita NaN: " + calculadora.validarResultado(Float.NaN));
        Log.i(TAG, "Prueba infinito: " + calculadora.validarResultado(Float.POSITIVE_INFINITY));
        Log.i(TAG, "=== FIN DE PRUEBAS ===");
    }

    private void registrar(Calculadora calc, int x, int y, Operacion op, String signo) {
        Log.i(TAG, x + " " + signo + " " + y + " = " + calc.ejecutar(x, y, op));
    }
}
