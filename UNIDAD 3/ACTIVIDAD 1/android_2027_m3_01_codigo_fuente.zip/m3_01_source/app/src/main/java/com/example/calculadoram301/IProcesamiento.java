package com.example.calculadoram301;

/** Contrato para las cuatro operaciones matematicas. */
public interface IProcesamiento {
    float suma(float x, float y);
    float resta(float x, float y);
    float multi(float x, float y);
    float div(float x, float y);
}
