# Android 2027 - M3-01: Calculadora con interfaces Java

## Preparacion

1. En Android Studio crear **Empty Views Activity** con lenguaje **Java**, nombre **CalculadoraM301**, y nombre de paquete **com.example.calculadoram301**.
2. Copiar los once archivos `.java` incluidos en `app/src/main/java/com/example/calculadoram301/` a la misma ruta dentro del proyecto creado, sustituyendo el `MainActivity.java` generado.
3. La plantilla debe incluir la dependencia de `androidx.appcompat:appcompat` (habitual en Empty Views Activity). La actividad no utiliza `setContentView` ni controles graficos.
4. Comprobar que `AndroidManifest.xml` apunta a `.MainActivity` como actividad de inicio.
5. Ejecutar con un emulador. Abrir **View > Tool Windows > Logcat** y filtrar por `tag:CalculadoraM3`.

## Que implementa
- `IProcesamiento`/`Procesamiento`: suma, resta, multiplicacion y division.
- `IControl`/`Control`: entrada de dos enteros, seleccion de operacion y calculo.
- `IDisplay`/`Display`: presentacion de resultados y errores como cadenas.
- `ICalculadora`/`Calculadora`: conexion de las piezas y validacion de NaN, infinito y division entre cero.
- `MainActivity`: pruebas sin interfaz grafica y resultados publicados mediante `Log.i`.

## Evidencia
Captura de Logcat con `tag:CalculadoraM3`, mostrando las cuatro operaciones y las validaciones.
No compartas datos personales ni logs ajenos a esta app.

## Nota sobre los archivos base
Se han conservado los nombres y firmas de los cuatro interfaces y dos enumeraciones proporcionados en la actividad. `Control.java` fue completado porque su version base solo tenia un `@override` invalido y no implementaba metodos.
