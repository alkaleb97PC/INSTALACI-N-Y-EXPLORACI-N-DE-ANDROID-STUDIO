# Actividad M4-01 - Ciclo de vida de una Activity en Java

## Instalacion en Android Studio
1. Crear proyecto Android Studio > New Project > Empty Views Activity, lenguaje Java.
2. Nombre: CicloVidaM401. Package name: com.example.ciclodevidam401.
3. Sustituir MainActivity.java del proyecto por el archivo incluido. Esta clase crea un TextView de forma programatica; no necesita modificar activity_main.xml.
4. Ejecutar en un emulador Android; abrir View > Tool Windows > Logcat.
5. Filtrar con: tag:CicloVidaM4
6. Observar onCreate/onStart/onResume al iniciar.
7. Pulsar Home en el emulador para activar onPause/onStop.
8. Volver a la aplicacion desde Apps recientes para observar onRestart/onStart/onResume.
9. Utilizar Atras en el emulador para finalizar de forma normal y observar onPause/onStop/onDestroy cuando corresponda. Android no garantiza que onDestroy se ejecute si el proceso se termina abruptamente.
10. Tomar capturas reales de codigo Java y Logcat e insertarlas en el Word; volver a exportar como android_2027_m4_01.pdf.

## Nota
Los registros del PDF inicial son ejemplos de mensajes esperados, NO son evidencia de ejecucion. Debes capturar tus propios registros en Logcat.

Documentacion: https://developer.android.com/guide/components/activities/activity-lifecycle
