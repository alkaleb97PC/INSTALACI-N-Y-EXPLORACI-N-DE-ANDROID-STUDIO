package com.example.ciclodevidam401;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "CicloVidaM4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView texto = new TextView(this);
        texto.setText("Actividad M4-01\nCiclo de vida de una Activity");
        texto.setTextSize(22);
        texto.setGravity(Gravity.CENTER);
        setContentView(texto);

        Log.i(TAG, "onCreate(): se creo la actividad.");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "onStart(): la actividad ahora es visible.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "onResume(): la actividad esta en primer plano.");
    }

    @Override
    protected void onPause() {
        Log.i(TAG, "onPause(): la actividad perdio el primer plano.");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.i(TAG, "onStop(): la actividad ya no es visible.");
        super.onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "onRestart(): la actividad regresa desde detenida.");
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG, "onDestroy(): la actividad sera destruida.");
        super.onDestroy();
    }
}
